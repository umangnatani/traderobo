// start:ng42.barrel
export * from './app.header.component';
export * from './base.component';
// end:ng42.barrel

