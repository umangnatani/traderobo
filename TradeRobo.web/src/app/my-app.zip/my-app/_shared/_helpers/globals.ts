import { Injectable } from '@angular/core';

@Injectable()
export class Globals {
  PageTitle: string;
  
}
