// start:ng42.barrel
export * from './login.component';

// end:ng42.barrel

