import { Component, OnDestroy, OnInit } from "@angular/core";
import {
    FormBuilder,
    FormGroup,
    FormControl,
    Validators,
} from "@angular/forms";
import { Subject } from "rxjs";
import {
    ApiService,
    NotificationService,
    BaseComponent,
    Globals,
} from "app/my-app/_shared";

@Component({
    selector: "app-multi-order",
    templateUrl: "./multi-order.component.html",
    styleUrls: ["./multi-order.component.scss"],
})
export class MultiOrderComponent extends BaseComponent implements OnInit {
    Watchlists;
    watchlistId = 0;

    form: FormGroup;
    isEdit = false;

    CurSymbol='';

    pieValue = "";
    folioForm: FormGroup;

    dataSource;
    orderSide = "buy";
    orderType = "multi";
    broker = "RH";
    showAdvanced = false;

    defaultColDef;

    rowClassRules;

    rowSelection;

    private gridApi;

    columnDefs = [

        {
            field: "Symbol",
            cellStyle: { "font-weight": "bold", color: "blue" },
            //cellClass: function(params) { return (params.data.pct_change > 0 ? 'green-900-fg': 'red-900-fg')  },
        },

        {
            field: "pct_change",
            headerName: "% Change",
            cellStyle: { "font-weight": "bold" },
            //cellClass: function(params) { return (params.value > 0 ? 'green-900': 'red-900')  },
            valueFormatter: (params) => {
                return params.value.toFixed(2) + "%";
            },
        },
        {
            field: "last_trade_price",
            valueFormatter: (params) => {
                return params.value.toFixed(2);
            },
            cellStyle: { "font-weight": "bold" },
            headerName: "Last Price",
        },
    ];

    constructor(
        private _formBuilder: FormBuilder,
        public apiService: ApiService,
        private notificationService: NotificationService,
        private globals: Globals
    ) {
        super(apiService);

        this.defaultColDef = {
            width: 100,
            sortable: true,
        };

        this.rowClassRules = {
            "red-900-fg": "data.pct_change < 0",
            "green-900-fg": "data.pct_change > 0",
        };

        this.rowSelection = "multiple";
    }

    ngOnInit(): void {
        this.folioForm = this._formBuilder.group({
            Amount: [100],
            Side: ["buy"],
            Symbol: [''],
            Quantity: [10],
            Price: [null],
            Increment: [.20],
            Total: [5],
        });

        this.form = this._formBuilder.group({
            Symbols: [],
        });

        this.loadWatchlist();

        this.loadWatchlistSymbols();
    }

    loadWatchlist() {
        this.apiService.getWatchlists().subscribe((data) => {
            this.Watchlists = data;
            // console.log(this.Pies);
        });
    }

    loadWatchlistSymbols() {
        this.apiService
        .getWatchlistSymbols(this.watchlistId)
        .subscribe((data) => {
            // console.log(data);
            this.dataSource = data;
        });
    }

    get f() { return this.folioForm.controls; }

    onRowSelected(event) {
        console.log(event.node.data);
        this.CurSymbol = event.node.data.Symbol;
        this.f.Symbol.setValue(this.CurSymbol);
        this.f.Price.setValue(event.node.data.bid_price)
        
      }


    public saveWatchlist(){
        // console.log(this.PieDetails);
        this.apiService.saveWatchListSymbols(this.watchlistId, this.form.value).subscribe((data) => {
            // console.log(data);
            this.apiService.setMessage2(data);
            this.loadWatchlistSymbols();
            // this.activePie = this.form.value;
        });
    }

    selectWatchlist(watchlist): void {
        this.watchlistId = watchlist.Id;
        this.isEdit = true;

        this.gridApi.deselectAll();

        this.loadWatchlistSymbols();
       
    }

    selectOrderSide(val: string): void {
        this.folioForm.controls.Side.setValue(val);
        this.orderSide = val;
    }

    selectOrderType(val: string): void {
        //this.folioForm.controls.Side.setValue(val);
        this.orderType = val;
    }

    selectBroker(val: string): void {
        //this.folioForm.controls.Side.setValue(val);
        this.broker  = val;
    }

    placeOrder(): void {
        const payload = this.gridApi.getSelectedRows();

        if (!this.showAdvanced){
            this.f.Total.setValue(1);
        }


        let data = this.folioForm.value;

        data.Symbols = payload;

      
        //console.log(data);

        this.Globals.IsBusy = true;
        this.apiService.placeComplexOrder(data, this.orderType, this.broker).subscribe((response) => {
            this.apiService.setMessage2(response);
            //this.dataSource = data.Object.Orders;
            this.Globals.IsBusy = false;
        });
    }

    checkAdvanced(){
        this.showAdvanced = !this.showAdvanced;
    }
  

    onGridReady(params) {
        this.gridApi = params.api;
        this.gridApi.sizeColumnsToFit();
    }

    ngOnDestroy(): void {}
}
