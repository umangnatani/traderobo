// start:ng42.barrel
export * from './user.component';
// end:ng42.barrel

